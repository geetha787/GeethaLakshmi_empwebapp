package com.capgemini.empwebapp.dao;

import com.capgemini.empwebapp.dto.EmployeBean;

public interface EmployeDao {
	
	public EmployeBean getEmployeDetails(String name);

	public boolean deleteEmploye(int id);

	public boolean updateEmploye(EmployeBean bean);

	public boolean createEmploye(EmployeBean bean);

	public boolean addEmploye(EmployeBean bean);

}
