package com.capgemini.empwebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import com.capgemini.empwebapp.dto.EmployeBean;
import com.capgemini.empwebapp.services.EmployeService;
import com.capgemini.empwebapp.services.EmployeServicesImpl;

public class EmployeServlets {
	private EmployeService service= new EmployeServicesImpl();
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// get query string
		String empIdVal = req.getParameter("empId");
		String empId =req.getParameter(empIdVal);
		String empName = req.getParameter("empName");
		String designation = req.getParameter("designation");
		
		
		EmployeBean bean  = new EmployeBean();
		bean.getId();
		bean.getName();
		bean.getDesignation();
		
		boolean isAdded= service.addEmploye(bean);
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		out.println("<html>");
		out.println("<body>");
		if(isAdded) {
			out.println("<h2 style'color: green'>Employee Added susscessfully.....</h2>");
		}else {
			out.println("<h2 style'color: red'>unable to add employee!!!</h2>");
			
		}
		out.println("</body>");
		out.println("</html>");

		

		
		
	}

}
