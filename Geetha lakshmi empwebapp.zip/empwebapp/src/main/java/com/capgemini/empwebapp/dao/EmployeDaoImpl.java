package com.capgemini.empwebapp.dao;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

import com.capgemini.empwebapp.dto.EmployeBean;

public class EmployeDaoImpl implements EmployeDao {

	@Override
	public EmployeBean getEmployeDetails(String name) {
		ResultSet res = null;
		String url = "jdbc:mysql://localhost:3306/emp_db?useSSL=false&user=root&password=root";
		String query = "select * from employee_info where name=?";
		try (Connection connection = DriverManager.getConnection(url);
				PreparedStatement preparedStatement = connection.prepareStatement(query);) {
			Class.forName("com.mysql.jdbc.Driver");

			preparedStatement.setString(1, name);
			res = preparedStatement.executeQuery();
			EmployeBean beans = new EmployeBean();
			if (res.next()) {
			    beans.setId(res.getString("id"));
				beans.setName(res.getString("name"));
				beans.setEmailId(res.getString("email"));
				beans.setMobilenono(res.getLong("mobilenono"));
				beans.setGender(res.getString("gender"));
				return beans;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {

				if (res != null) {
					res.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public boolean deleteEmploye(int id) {
		String url = "jdbc:mysql://localhost:3306/emp_db?useSSL=false&user=root&password=root";
		String query = "delete from employee_info where eid=?";

		try (Connection connection = DriverManager.getConnection(url);
				PreparedStatement preparedStatement = connection.prepareStatement(query);) {
			Class.forName("com.mysql.jdbc.Driver");
			preparedStatement.setInt(1, id);
			int res = preparedStatement.executeUpdate();
			if (res != 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateEmploye(EmployeBean bean) {
		String query = "update employee_info set name=? where eid=?";
		String url = "jdbc:mysql://localhost:3306/emp_db?useSSL=false&user=root&password=root";
		try (Connection connection = DriverManager.getConnection(url);
				PreparedStatement preparedStatement = connection.prepareStatement(query);) {
			Class.forName("com.mysql.jdbc.Driver");
			preparedStatement.setString(1, bean.getName());
			preparedStatement.setString(2, bean.getId());
			int res = preparedStatement.executeUpdate();
			if (res != 0) {
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean createEmploye(EmployeBean bean) {
		String url = "jdbc:mysql://localhost:3306/emp_db?useSSL=false&user=root&password=root";
		String query = "insert into employee_info values(?,?,?,?,?,?,?,?,?,?,?,?)";
		try (Connection connection = DriverManager.getConnection(url);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);) {
			Class.forName("com.mysql.jdbc.Driver");
			preparedStatement.setString(1, bean.getId());
			preparedStatement.setString(2, bean.getName());
			preparedStatement.setString(4, bean.getEmailId());
			preparedStatement.setLong(3, bean.getMobilenono());
			preparedStatement.setString(5, bean.getGender());
			preparedStatement.setInt(6, bean.getAge());
			preparedStatement.setLong(7, bean.getDob());
			preparedStatement.setString(8, bean.getDesignation());
			preparedStatement.setLong(9, bean.getSalary());
			preparedStatement.setLong(11, bean.getDoj());

			

			int res = preparedStatement.executeUpdate();

			if (res != 0) {
				return true;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean addEmploye(EmployeBean bean) {
		String url = "jdbc:mysql://localhost:3306/emp_db?useSSL=false&user=root&password=root";
		String query = "select * from employee_info ";

		List<EmployeBean> info = new LinkedList<EmployeBean>();
		try (Connection connection = DriverManager.getConnection(url);
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				ResultSet res = preparedStatement.executeQuery();) {
			Class.forName("com.mysql.jdbc.Driver");
			while (res.next()) {
				EmployeBean beans = new EmployeBean();

				beans.setId(res.getString("eid"));
				beans.setName(res.getString("name"));
				beans.setEmailId(res.getString("email"));
				beans.setMobilenono(res.getLong("mobilenono"));
				beans.setGender(res.getString("gender"));
				beans.setAge(res.getInt("age"));
				beans.setDesignation(res.getString("designation"));
				beans.setDoj(res.getLong("doj"));
				beans.setDob(res.getLong("dob"));
				beans.setSalary(res.getLong("salary"));
				info.add(beans);
			}

			if (info.isEmpty()) {
				return null ;
			} else {
				return info;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return false;
	}

	

}
