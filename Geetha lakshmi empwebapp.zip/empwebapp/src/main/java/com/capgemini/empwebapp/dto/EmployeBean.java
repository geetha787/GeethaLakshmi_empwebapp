package com.capgemini.empwebapp.dto;

public class EmployeBean {
	private String id;
	private String name;
	private long mobilenono;
	private String emailId;
	private String gender;
	private int age;
	private long dob;
	private String designation;
	private long salary;
	private long doj;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobilenono() {
		return mobilenono;
	}
	public void setMobilenono(long mobilenono) {
		this.mobilenono = mobilenono;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getDob() {
		return dob;
	}
	public void setDob(long dob) {
		this.dob = dob;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	public long getDoj() {
		return doj;
	}
	public void setDoj(long doj) {
		this.doj = doj;
	}
	
}
