package com.capgemini.empwebapp.services;

import java.util.List;

import com.capgemini.empwebapp.dto.EmployeBean;

public interface EmployeService {
	public boolean createEmploye(EmployeBean bean);

	public boolean addEmploye(EmployeBean bean);

	public boolean updateEmploye(EmployeBean bean);

	public boolean deleteEmploye(int id);

	public EmployeBean getEmploye(String name);

	public List<EmployeBean> getAllEmployeeDetails();

	public EmployeBean authenticate(int id, String empPass);


}
