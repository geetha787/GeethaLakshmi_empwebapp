package com.capgemini.empwebapp.services;

import java.util.List;

import com.capgemini.empwebapp.dto.EmployeBean;
import com.capgemini.empwebapp.dao.EmployeDao;
import com.capgemini.empwebapp.dao.EmployeDaoImpl;

public  class EmployeServicesImpl implements EmployeService {
	EmployeDao dao = new  EmployeDaoImpl();
	@Override
	public boolean createEmploye(EmployeBean bean) {
		return dao.createEmploye(bean);
	}

	@Override
	public boolean addEmploye(EmployeBean bean) {
		return dao.addEmploye(bean);
	}

	@Override
	public boolean updateEmploye(EmployeBean bean) {
		return dao.updateEmploye(bean);
	}

	@Override
	public boolean deleteEmploye(int id) {
		return dao.deleteEmploye(id);
	}

	@Override
	public EmployeBean getEmploye(String name) {
		return dao.getEmployeDetails(name);
	}

	@Override
	public List<EmployeBean> getAllEmployeeDetails() {
		return null;
	}

	@Override
	public EmployeBean authenticate(int id, String empPass) {
		return null;
	}

}
